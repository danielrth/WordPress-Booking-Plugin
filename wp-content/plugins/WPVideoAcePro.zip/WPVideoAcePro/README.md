# Custom Youtube Player

WordPress plugin for adding custom post type for embedding youtube video with full screen and thumbnail mode settings.

### Dependency 
https://github.com/rilwis/meta-box